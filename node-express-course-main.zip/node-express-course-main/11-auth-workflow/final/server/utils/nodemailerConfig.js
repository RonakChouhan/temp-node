module.exports = {
  host: 'smtp.ethereal.email',
  port: 587,
  auth: {
    user: 'tommie.schamberger92@ethereal.email',
    pass: '3FzkhF7Ut17qFdx3Qx',
  },
};
